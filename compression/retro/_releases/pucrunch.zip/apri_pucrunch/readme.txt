##################
## PUCRUNCH
##################

06.01.2006
This is modified version of PuCrunch. I remove additional headers from packed file to get smaller packed file and decrease size of decompressor.

Aprisobal
aprisobal@tut.by