/**************************************************************************
 *
 * rbuc.c -- driver for the "rbuc" package
 *
 * "rbuc" is the demonstration of the coding scheme "rbuc-B",
 * described in the paper "Binary Codes for Non-Uniform Sources"
 * by Moffat and Anh, to appear in the Proceedings of 
 * 2005 Data Compression Conference.
 *   
 * Copyright (C) 2005  Authors: Vo Ngoc Anh & Alistair Moffat
 *

 * We ask that, if you use this software to derive experimental results
 * that are reported in any way, you cite the original work in which the
 * underlying processes are described (by referencing the listed paper);
 * and also acknowledge our authorship of the implementation you have
 * used.

 * BUGS
 * rbuc has not been extensively tested, and should be used for research
 * purposes only.
 * Portability is not guaranteed.
 * There is no warranty, either express or implied, that it is fit for
 * any purpose whatsoever, and neither the authors nor The University of
 * Melbourne accept any responsibility for any consequences that may
 * arise from your use of this software.

 * LICENSE
 * Use and modify for your personal use, but do not distribute in any
 * way shape or form (for commercial or noncommercial purposes, modified
 * or unmodified, including by passively making it available on any
 * internet site) without prior consent of the authors.

 * AUTHORS
 * Vo Ngoc Anh and Alistair Moffat,
 * Department of Computer Science and Software Engineering,
 * The University of Melbourne,
 * Victoria 3010, Australia.
 * Email: vo@cs.mu.oz.au, alistair@cs.mu.oz.au.
 *
 **************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "uncompress_io.h"
#include "rbuc_coder.h"

#define _DEBUG 0
#define yes 1
#define no 0
#define ENCODE 0
#define DECODE 1


void
ProcessArguments(int *coding_type, int *sequence_type, 
    int *text_file, int *verbose, unsigned *N, unsigned *p, int *epb, int *type,
    char *ifile, char *ofile, int argc, char *argv[]);




int main(int agrc, char *argv[])
{
  int coding_type;
  int sequence_type;
  int text_file;
	int verbose;
  
  unsigned N;
  unsigned p;

  unsigned len;
  unsigned tmp;
  unsigned *a=NULL;
  int epb= 0;    // change by -E parameter, 
	               // - E 0 (default)= rbuc-B, -E 4 = rbuc-4 
  int type= MS_EXP;

 
  unsigned global_max, global_sum, global_n;

  char ifile[MAXFILENAME+1], ofile[MAXFILENAME+1];

  ProcessArguments(&coding_type, &sequence_type, &text_file, &verbose,
    &N, &p, &epb, &type, ifile, ofile, agrc, argv);
    
 
  if (!(a=(unsigned *) malloc (sizeof(unsigned)*ELEMS_PER_BLOCK)))
  {
    fprintf(stderr,"Cannot allocate memory for the array of docnums\n");
    exit(1);
  }
 
  if (coding_type==ENCODING)
  {
    if (( len = rbucEncodeFile(a, ifile, ofile,text_file, sequence_type,
            N, p, &global_max, &global_sum, &global_n, epb, type, verbose))< 0)
      return 1;
    if (verbose)
    {
      int i;
      unsigned max=0;
      float bpd;
      bpd = global_n? (len<<5)/(float)global_n : 0;
      fprintf (stderr, "Number of symbols       = %u\n",global_n);
      fprintf (stderr, "Average symbol          = %.2f\n",
                global_n? global_sum/(float)global_n : 0);
      fprintf (stderr, "Maximum symbol	        = %u\n",global_max);
      if (bpd>0 && bpd<34)
      {
        fprintf (stderr, "Total output words      = %u\n",len);
        fprintf (stderr, "Average bits per symbol = %.2f\n",bpd);
      }
      else
	      fprintf (stderr, "Bits per symbol not available,\n"
	                 "  to have it, you need to use parameter -o,"
			             "  or direct output to a file\n");
    }
  }
  else
  {
    if (!rbucDecodeFile(a, ifile, ofile, text_file, sequence_type,epb,type))
			return 1;
  }    
  if (a) free(a);
  return 0;
}  


  
/*-------------------------
  Processing arguments to the main()
-------------------------*/

void
ProcessArguments(int *coding_type, int *sequence_type, int *text_file, int *verbose,
  unsigned *N, unsigned *p, int *epb, int *type, char *ifile, char *ofile,
  int argc, char *argv[])
{
  int error = 0;
  char ch;
  *coding_type = ENCODING;
  *sequence_type = DOCGAP;
  *N= 0;
  *p= 0;
  *verbose= no;
  *ifile = '\0';
  *ofile = '\0';
  *text_file = no;
 
  while ((ch = getopt (argc, argv, "vxdhtN:p:i:o:E:T:")) != -1)
    switch (ch)
    {
      case 'x':
        *coding_type = DECODING;
        break;
      case 'd':
        *sequence_type = DOCNUM;
        break;
      case 't':
        *text_file = yes;
        break;
      case 'v':
        *verbose = yes;
        break;
      case 'N':
	      *N= atoi(optarg);
	      break;
      case 'p':
        *p= atoi(optarg);
        break;
      case 'E':
        *epb= atoi(optarg);
        break;
      case 'T':
        *type= atoi(optarg);
        break;
      case 'i':
        strncpy(ifile,optarg,MAXFILENAME);
        break;
      case 'o':
        strncpy(ofile,optarg,MAXFILENAME);
        break;
      case 'h':
      default :
        error = 1;
	break;
    }
  if (optind < argc) error = 1;
  if ( *N && !(*p) || !(*N) && *p
       || *N && *ifile
     )  
    error = 1;
  if (error)
  {
    fprintf(stderr,
	"-------------------------------------------------------------\n"
	"   This program compress/decompress sequence of document\n"
	"numbers/gaps using rbuc method, described in the\n"
	"paper \"Binary Codes for Non-Uniform Sources\" \n"
	"by Alistair Moffat and Vo Ngoc Anh (DCC-2005)\n"
	"-------------------------------------------------------------\n");
	
    fprintf( stderr, 
       "Usage:\n%s\t[-x] : extract file instead of compress \n"
       "\t[-d] : uncompressed sequence is of docnums, instead of d-gaps \n"
       "\t[-t] : uncompressed sequence is of text form instead of binary \n"
       "\t[-N N -p p] : generating p docnums valued up to N, OR \n"
       "\t\t[-i input_file_name] : default= stdin \n"
       "\t[-o output_file_name] : default= stdout\n"
       "\t[-v] : (verbose:) print statistics (not working with -x option)\n"
       "\t[-h] : print this message \n", argv [0]);
    fprintf( stderr,
	"-------------------------------------------------------------\n"
        "Examples:	\n"
	"\trbuc -i SMALL -o BIG        : compress file \"SMALL\", write to \"BIG\"\n"
	"\trbuc < SMALL > BIG          : same as above\n"
	"\trbuc -t < SMALL > BIG       : same as above,\n"
	"\t                               but \"SMALL\" is in text format\n"
	"\trbuc -t -d < SMALL > BIG    : same as above,\n"
	"\t                               but \"SMALL\" contains sequence\n"
	"\t                               of document numbers, not gaps\n"
	"\trbuc -x -t < BIG            : Decompress file \"BIG\",\n"
	"\t                               and write text output to stdout\n"
	"\trbuc -N 10000 -p 100 > SMALL: randomly generate 100 document numbers\n"
	"\t                               for a hypothesis collection of 10000\n"
	"\t                               docs, compress them to \"SMALL\"\n");   
    fprintf( stderr,
	"-------------------------------------------------------------\n"
	"   Thank you for using this program.\n"
        "   If you have any comment, please send to vo@cs.mu.oz.au.\n\n");
    exit(1);
  }
  
  if (*N && (*N<*p ||  ( *p<(1<<12) &&  *N> (*p<<25) )) )
  {
    fprintf (stderr, "Value -N and/or -p not appropriate\n");
    exit(1);
  }
  
  return;
}
       
