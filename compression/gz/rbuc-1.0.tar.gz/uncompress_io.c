/**************************************************************************
 *
 * uncompress_io.c -- function for io uncompressed files
 *                    part of "rbuc"
 *
 * "rbuc" is the demonstration of the coding scheme "RBUC-B",
 * described in the paper "Binary Codes for Non-Uniform Sources"
 * by Moffat and Anh, to appear in the Proceedings of 
 * 2005 Data Compression Conference.
 *   
 * Copyright (C) 2005  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 
 * We ask that, if you use this software to derive experimental results
 * that are reported in any way, you cite the original work in which the
 * underlying processes are described (by referencing the listed paper);
 * and also acknowledge our authorship of the implementation you have
 * used.

 * BUGS
 * rbuc has not been extensively tested, and should be used for research
 * purposes only.
 * Portability is not guaranteed.
 * There is no warranty, either express or implied, that it is fit for
 * any purpose whatsoever, and neither the authors nor The University of
 * Melbourne accept any responsibility for any consequences that may
 * arise from your use of this software.

 * LICENSE
 * Use and modify for your personal use, but do not distribute in any
 * way shape or form (for commercial or noncommercial purposes, modified
 * or unmodified, including by passively making it available on any
 * internet site) without prior consent of the authors.

 * AUTHORS
 * Vo Ngoc Anh and Alistair Moffat,
 * Department of Computer Science and Software Engineering,
 * The University of Melbourne,
 * Victoria 3010, Australia.
 * Email: vo@cs.mu.oz.au, alistair@cs.mu.oz.au.
 *
 * 
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "uncompress_io.h"
#include "rbuc_coder.h"

FILE *
OpenFile(char *filename, char *mode)
{
  FILE *f= NULL;
  if (*filename)
    {
    if (!(f = fopen(filename, mode)))
      fprintf(stderr, "Cannot open file %s\n", filename);
    }
  else 
    f= *mode=='r'? stdin : stdout ;

  return f;
}  
    



/*-------------------------
   Read at most "*n" intergers from "filename" to "a"
   flag = 0 : input numbers intepreted as document gaps
   flag = 1 : input numbers intepreted as document number
   text_file = 1 if reading from a text file
   return 1 if Ok, 0 otherwise; 
          *n = number of items read;
-------------------------*/
   
int
ReadDocGaps(unsigned int *a, unsigned int *n, FILE *f, 
    int text_file, int flag, unsigned *global_curr)
{
  int i;
  unsigned curr=*global_curr;
  int tmp, bytes;

  for (i=0; !feof(f) && i<ELEMS_PER_BLOCK; i++)
  {
	       if (feof(f)) { break;};
    if (text_file)
      if ( fscanf(f, " %d ", &tmp) != 1)
      {
         fprintf(stderr, "Errors when reading file\n");
         exit(1);
      }
    if (!text_file)
      if ( (bytes=fread( (char*) &tmp, sizeof(char), 4, f)) != 4)
      {
	       // if (feof(f)) { break;};
	       if (!bytes) { break;};
         fprintf(stderr, "Errors when reading file \n");
         exit(1);
      }
    if (flag==DOCNUM)
    {
      if (tmp <= curr)
      {
	fprintf(stderr, "Error: sequence not in increasing order"
	                " at item number %d\n",i+1);
	fprintf(stderr, "Suggestion: when using -d option for compression "
	    "be sure that the input file is a sequence of positive"
	    " numbers in strictly increasing order\n");
	    
	exit(1);
      }
      a[i] = tmp - curr;
      curr = tmp;
    }
    else
    {
      if (tmp <= 0)
      {
	fprintf(stderr, "Error: invalid d-gap"
	                " at item number %d\n",i+1);
	exit(1);
      }
      a[i]= tmp;
    }
  }
  *n = i;
  *global_curr= curr;
  return i;
}


/*-------------------------
 Write "n" item from "a" to file "filename"
-------------------------*/   

int
WriteDocGaps(FILE *f, unsigned int *a, unsigned int n, char *filename, int text_file, int flag, unsigned *global_curr)
{
  unsigned i;
 
  if (flag==DOCNUM)
  { 
    a[0] = *global_curr + a[0];
    for (i=1; i<n; i++) a[i] += a[i-1];
    *global_curr= a[n-1];
  }
      
  if (text_file)
    for (i=0; i<n; i++)
    {
      if ( fprintf(f,"%u\n", a[i]) <1 )
      {
        fprintf(stderr, "Errors when writing file %s\n", filename);
        return 0;
      }
    }
  else
    if ( fwrite( (char*) a, sizeof(unsigned int), n, f) != n)
    {
      fprintf(stderr, "Errors when writing file %s\n", filename);
      return 0;
    }
  
  return 1;
}
  


/*-------------------------
-------------------------*/   
int 
CreateDocGaps(unsigned *a, unsigned *nn, double Pr)
{
  double pr;
  char *A;
  int x,i,j;
  unsigned N, n= *nn;
  unsigned newn;
  
  if (n<1) return 0;
  
  if (n>ELEMS_PER_BLOCK)
  {
    n= ELEMS_PER_BLOCK;
  }
  N= n*Pr + 0.5;
  if (N<n) N=n;
  *nn= *nn - n;
  newn= n;
    
  if (N>LIMIT)
  {
    fprintf (stderr, "Value -N and/or -p not appropriate\n");
    exit(1);
  }
  
  if (!(A = malloc(N)))
  {
    fprintf(stderr, "No memory\n");
    exit(1);
  }
  for (i=0; i<N; i++) A[i] = 0;
 
  while (n)
  {
    x = random()%N;
    if (!A[x]) { A[x] = 1; n--; }
  }  
  for (x=0,i=0,j=0; i<N; i++) 
    if (A[i]) {a[j++]= i+1-x; x=i+1;}
  
  free(A);
  return newn;
}

  
  
      
  
  
