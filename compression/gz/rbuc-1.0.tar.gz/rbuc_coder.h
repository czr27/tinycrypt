/**************************************************************************
 *
 * rbuc_coder.h -- macros for rbuc coding
 *                  part of "rbuc"
 * 
 * "rbuc" is the demonstration of the coding scheme "RBUC-B",
 * described in the paper "Binary Codes for Non-Uniform Sources"
 * by Moffat and Anh, to appear in the Proceedings of 
 * 2005 Data Compression Conference.
 *   
 * Copyright (C) 2005  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 
 * We ask that, if you use this software to derive experimental results
 * that are reported in any way, you cite the original work in which the
 * underlying processes are described (by referencing the listed paper);
 * and also acknowledge our authorship of the implementation you have
 * used.

 * BUGS
 * rbuc has not been extensively tested, and should be used for research
 * purposes only.
 * Portability is not guaranteed.
 * There is no warranty, either express or implied, that it is fit for
 * any purpose whatsoever, and neither the authors nor The University of
 * Melbourne accept any responsibility for any consequences that may
 * arise from your use of this software.

 * LICENSE
 * Use and modify for your personal use, but do not distribute in any
 * way shape or form (for commercial or noncommercial purposes, modified
 * or unmodified, including by passively making it available on any
 * internet site) without prior consent of the authors.

 * AUTHORS
 * Vo Ngoc Anh and Alistair Moffat,
 * Department of Computer Science and Software Engineering,
 * The University of Melbourne,
 * Victoria 3010, Australia.
 * Email: vo@cs.mu.oz.au, alistair@cs.mu.oz.au.
 *
 *
 **************************************************************************/


#ifndef _MS_CODERH
#define _MS_CODERH

#include "word_coder.h"

int
CalcMinBits(int *gaps, unsigned char *bits, int n, unsigned *global_max, unsigned *global_sum, unsigned *global_n);

int
rbucEncode(unsigned *a, unsigned char **bits, unsigned *ns,
		unsigned l, int elem, int size, int s, int epb, int type);

int
rbucEncodeFile(unsigned *a, char *ifile, char *ofile,
  int text_file, int sequence_type, unsigned N, unsigned p,
  unsigned *global_max, unsigned *global_sum, unsigned *global_n,
  int epb, int type, int verbose);

int
rbucDecode(unsigned *a, unsigned *ns,
		    unsigned l, int elem, int size, int s, int epb, int type);

int
rbucDecodeFile(unsigned *a,  char *ifile,
   char *ofile, int text_file, int sequence_type,
	 int epb, int type);

	

/* coding types */
#define MS_CONST 1   /* all level use the same len */
#define MS_EXP   2   /* len of next level = previous-len * epb */ 

#define MAX_LEVELS 20


#define BIT_FOR_ZERO_LEN 6
#define MAX_ELEM_PER_WORD 64
#define MASK_FOR_ZERO_LEN 63
#define TRANS_TABLE_STARTER 33

#define ELEMS_PER_BLOCK	16384
#define BITS_FOR_ELEMS_PER_BLOCK	14
#define LOGA_BITS_FOR_ELEMS_PER_BLOCK	4


#define CEILLOG_2(x,v)                                                  \
do {                                                                    \
  register int _B_x  = (x) - 1;                                         \
  (v) = 0;                                                              \
  for (; _B_x ; _B_x>>=1, (v)++);                                       \
} while(0)

#define QCEILLOG_2(x,v)							\
do {                                                                    \
  register int _B_x  = (x) - 1;                                         \
  (v) = _B_x>>16 ?							\
         (_B_x>>24 ? 24 + CLOG2TAB[_B_x>>24] : 16 | CLOG2TAB[_B_x>>16]) \
	 :								\
	 (_B_x>>8 ? 8 + CLOG2TAB[_B_x>>8] : CLOG2TAB[_B_x]) ;		\
} while (0)
      
#define QZEROCEILLOG_2(x,v)							\
do {                                                                    \
  register int _B_x  = (x);                                         \
  (v) = _B_x>>16 ?							\
         (_B_x>>24 ? 24 + CLOG2TAB[_B_x>>24] : 16 | CLOG2TAB[_B_x>>16]) \
	 :								\
	 (_B_x>>8 ? 8 + CLOG2TAB[_B_x>>8] : CLOG2TAB[_B_x]) ;		\
} while (0)
      


#define CLOG2TAB_VAR							\
unsigned char CLOG2TAB[]={						\
0, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 }





#define GET_TRANS_TABLE(avail) avail<2? (avail=30, __pc30) : (avail-=2, __pc32)
  

/* ======================= MACROS FOR ENCODING ===== */

/* Setting variables for encoding     				
   f is output file description
   pn is (pointer to) number of elements
   max_bits is bits needed to code the largest element 
*/
#define MS_ENCODE_START(f) 			                        \
  WORD_ENCODE_START(f);		

/* Finish encoding, writing working word to output */
#define MS_ENCODE_END						\
  WORD_ENCODE_END;							\

			
																															
#define MS_BLOCK_ENCODE_START(n)				\
do {									\
  /* write number of elements */					\
  if (n==ELEMS_PER_BLOCK) {						\
    WORD_CROSS_ENCODE(1,1);							\
	} else									\
  {									\
    WORD_CROSS_ENCODE(2,1); 							\
    WORD_ZERO_CROSS_ENCODE(n,BITS_FOR_ELEMS_PER_BLOCK);			\
  }									\
} while(0)

/* ======================= MACROS FOR DECODING ===== */

#define MS_DECODE_START(f) 			                        \
  WORD_DECODE_START(f);	
  
#define MS_BLOCK_DECODE_START(n)					\
do  {									\
  WORD_CROSS_DECODE(n, 1);							\
  if (n==2) {								\
    WORD_ZERO_CROSS_DECODE(n, BITS_FOR_ELEMS_PER_BLOCK);			\
	} else								\
    n= ELEMS_PER_BLOCK;						\
} while (0)  						


#define MS_DECODE_END						\
  WORD_DECODE_END;							



#endif
	
      
    



