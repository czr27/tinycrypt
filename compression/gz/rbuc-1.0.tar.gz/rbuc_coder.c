/**************************************************************************
 *
 * rbuc_coder.c -- functions for rbuc encoding/decoding
 *                  part of "rbuc"
 *
 * "rbuc" is the demonstration of the coding scheme "RBUC-B",
 * described in the paper "Binary Codes for Non-Uniform Sources"
 * by Moffat and Anh, to appear in the Proceedings of 
 * 2005 Data Compression Conference.
 *   
 * Copyright (C) 2005  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 
 * We ask that, if you use this software to derive experimental results
 * that are reported in any way, you cite the original work in which the
 * underlying processes are described (by referencing the listed paper);
 * and also acknowledge our authorship of the implementation you have
 * used.

 * BUGS
 * rbuc has not been extensively tested, and should be used for research
 * purposes only.
 * Portability is not guaranteed.
 * There is no warranty, either express or implied, that it is fit for
 * any purpose whatsoever, and neither the authors nor The University of
 * Melbourne accept any responsibility for any consequences that may
 * arise from your use of this software.

 * LICENSE
 * Use and modify for your personal use, but do not distribute in any
 * way shape or form (for commercial or noncommercial purposes, modified
 * or unmodified, including by passively making it available on any
 * internet site) without prior consent of the authors.

 * AUTHORS
 * Vo Ngoc Anh and Alistair Moffat,
 * Department of Computer Science and Software Engineering,
 * The University of Melbourne,
 * Victoria 3010, Australia.
 * Email: vo@cs.mu.oz.au, alistair@cs.mu.oz.au.
 *
 **********************************************************************/

#define DEBUG 0

#include <stdio.h>
#include "uncompress_io.h"
#include "rbuc_coder.h"

/* bits[i]= bits needed to code gaps[i]
   return max(bits[i])
*/
int
CalcStats(int *gaps, int n, unsigned *global_max, unsigned *global_sum, unsigned *global_n)
{
  register int i;
  register int max=0;
  register unsigned gmax= *global_max;
  register unsigned gsum= *global_sum;
	register unsigned tmp;
  CLOG2TAB_VAR;
  for (i=0; i<n; i++)
  { 
    if (gmax<gaps[i]) gmax= gaps[i];
    QCEILLOG_2(gaps[i], tmp);
    if (max<tmp) max= tmp;
    gsum += gaps[i];
  }
  *global_max= gmax;
  *global_sum= gsum;
  *global_n += n;
  return max;
}

int totalbits=0;
/* cacl the _bits_ tree
  _bits_:  bits[0] is level 0, not used
	         level 1: bits[1][j] is bits needed to encode group j of a[]
					          group j of a[] is a[j*epb..(j+1)*epb-1]
					 level k: bits[k][j] is bits needed to encode group j of bits[k-1][]
*/
void
CaclBitSize(unsigned *a, unsigned char *bits, unsigned n)
{
	int i;
	int tmp;
	CLOG2TAB_VAR;
	for (i=0; i<n; i++) {
		QCEILLOG_2(a[i], tmp);
		bits[i]= tmp;
	}
}

	
int
CaclrbucBits(unsigned *a, unsigned char **bits, unsigned *ns, unsigned levels, int epb, int type)
{
	int i,j,k,l,tmp;
	int s= epb;   /* s number of elems per  block */
	unsigned char *src, *dest;
	unsigned max;
	int sum=0;
	CLOG2TAB_VAR;

	/* cacl first level from a */
	i=1;
	dest= bits[i];
	for (j=0,k=0; j<ns[i]; j++) {
		for( l=0,max=0; l<s && k<ns[i-1]; k++,l++) {
			tmp= bits[0][k];
	    if (max<tmp) max= tmp;
		}
		dest[j]= max;
		totalbits += max*l;
		sum += max*l;
	}
	
	/* calc remaining level of _bits_ tree */
	for (i=2; i<levels; i++) {
		if (type==MS_EXP) s *= epb;
		src= bits[i-1];
		dest=bits[i];
		for (j=0,k=0; j<ns[i]; j++) {
			for( l=0,max=0; l<s && k<ns[i-1]; k++,l++) {
				QZEROCEILLOG_2(src[k], tmp);
				if (max<tmp) max= tmp;
			}
			dest[j]= max;
			totalbits += max*l;
			sum += max*l;
		}
	}

	return sum;
}
			
int
CodeLength(unsigned char **bits, int n, int epb, int type)
{
	int i,j,k,l,tmp,n1;
	int s= epb;   /* s number of elems per  block */
	unsigned char *src, *dest;
	unsigned max;
	int sum=0;
	CLOG2TAB_VAR;

	/* cacl first level from a */
	i=1;
	dest= bits[i];
	n1= (n+s-1)/s;
	for (j=0,k=0; j<n1; j++) {
		for( l=0,max=0; l<s && k<n; k++,l++) {
			tmp= bits[0][k];
	    if (max<tmp) max= tmp;
		}
		dest[j]= max;
		sum += max*l;
	}
	
  n=n1;

	i=2;
	while (n>1) {
    if (type==MS_EXP) s *= epb;
		n1 = (n+s-1)/s;
		src= bits[i-1];
		dest=bits[i];
		for (j=0,k=0; j<n1; j++) {
			for( l=0,max=0; l<s && k<n; k++,l++) {
				QZEROCEILLOG_2(src[k], tmp);
				if (max<tmp) max= tmp;
			}
			dest[j]= max;
			sum += max*l;
		}
		n= n1;
		i++;
	}
		
	return sum;
}
			

// returning optimal value for epb, from set 2,4,8,16, ...
int
rbucOptimalEpb(unsigned char **bits, int n, int epb, int type)
{
	int opt=0, opt_cost=0;
	int sol, cost, max;
	
	for (sol=2; sol< 8; sol++) {
		cost = CodeLength(bits,n,sol,type);
		if (opt==0 || cost<=opt_cost) {
			opt= sol;
			opt_cost= cost;
		}
	}
	for (; sol< 32 ; sol += 4) {
		cost = CodeLength(bits,n,sol,type);
		if (opt==0 || cost<=opt_cost) {
			opt= sol;
			opt_cost= cost;
		}
	}
	for (; sol< n ; sol *= 2) {
		cost = CodeLength(bits,n,sol,type);
		if (opt==0 || cost<=opt_cost) {
			opt= sol;
			opt_cost= cost;
		}
	}
	
	return opt;
}
		

/* return number of levels & calc number of elems for each levels ns[]
 * number of levels is the depth of the _bits_ tree
 * _n_ : number of elems to be coded 
 * _highest_epb_ will be the number of elems per blocks at the root level
 * Note that level 0 is leaf */
int 
rbucLevels(int n, int epb, int type, unsigned *ns, int *highest_epb)
{
	int s= epb;   /* s number of elems per  block */
	int l=0;
	while (n>1) {
		ns[l]= n;
		n = (n+s-1)/s;
		l++;
		if (type==MS_EXP && n>1) s *= epb;
	}
	ns[l++]= n;
	*highest_epb= s;
	return l;
}	

int
FlatrbucEncode(unsigned *a, unsigned char **bits, 
		unsigned *ns, unsigned l, int elem, int size, int s, int epb, int type) 
{
	int i,j,k;
	int next_s=  type==MS_EXP? s/epb : s;
	int next_size, next_next_size, next_next_s;
  
  WORD_ZERO_CROSS_ENCODE(bits[l][elem],size);
	size= bits[l][elem];
	switch (l) {
		case 3:
			next_next_s= type==MS_EXP? next_s/epb : next_s;
			for (i=elem*s; i<(elem+1)*s && i<ns[2]; i++) {
				next_size= bits[l-1][i];
				WORD_ZERO_CROSS_ENCODE(next_size,size);
				for (j=i*next_s; j<(i+1)*next_s && j<ns[1]; j++) {
					next_next_size= bits[l-2][j];
					WORD_ZERO_CROSS_ENCODE(next_next_size,next_size);
				  for (k=j*next_next_s; k<(j+1)*next_next_s && k<ns[0]; k++)
						WORD_CROSS_ENCODE(a[k],next_next_size);
				}	
			}
			break;
		case 2:
			for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++) {
				next_size= bits[l-1][i];
				WORD_ZERO_CROSS_ENCODE(next_size,size);
				for (j=i*next_s; j<(i+1)*next_s && j<ns[l-2]; j++) 
					WORD_CROSS_ENCODE(a[j],next_size);
			}
			break;
		case 1:
			for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
				WORD_CROSS_ENCODE(a[i],size);
			break;
		default:
			for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
				FlatrbucEncode(a,bits,ns,l-1,i,bits[l][elem],next_s,epb,type);
	}
}

/* A pre-order traversal 
 * to emcode the subtree rooted at level l, elem-th element 
 * supposing the root is coded in _size_ bits
 * s is the number of children of the root */
int
rbucEncode(unsigned *a, unsigned char **bits, 
		unsigned *ns, unsigned l, int elem, int size, int s, int epb, int type) 
{
	int i;
	int next_s=  type==MS_EXP? s/epb : s;
 
	
	if (l>4) {
		WORD_ZERO_CROSS_ENCODE(bits[l][elem],size);
		for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
				rbucEncode(a,bits,ns,l-1,i,bits[l][elem],next_s,epb,type);
	}	else if (l==4){
		WORD_ZERO_CROSS_ENCODE(bits[l][elem],size);
		for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
				FlatrbucEncode(a,bits,ns,l-1,i,bits[l][elem],next_s,epb,type);
	} else 
		FlatrbucEncode(a,bits,ns,l,elem,size,s,epb,type);
}

int
FlatrbucDecode(unsigned *a, unsigned *ns, 
		unsigned l, int elem, int size, int s, int epb, int type) 
{
	int next_size, i;
	int next_s=  type==MS_EXP? s/epb : s;
	register int next_next_size, j;
	register int next_next_next_size, k;
	register int next_next_s;

	WORD_ZERO_CROSS_DECODE(next_size,size);
	switch (l) {
		case 3:
			next_next_s= type==MS_EXP? next_s/epb : next_s;
			for (i=elem*s; i<(elem+1)*s && i<ns[2]; i++) {
				WORD_ZERO_CROSS_DECODE(next_next_size,next_size);
				for (j=i*next_s; j<(i+1)*next_s && j<ns[1]; j++) {
					WORD_ZERO_CROSS_DECODE(next_next_next_size,next_next_size);
				  for (k=j*next_next_s; k<(j+1)*next_next_s && k<ns[0]; k++)
						WORD_CROSS_DECODE(a[k],next_next_next_size);
				}	
			}
			break;
		case 2:
			for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++) {
				WORD_ZERO_CROSS_DECODE(next_next_size,next_size);
				for (j=i*next_s; j<(i+1)*next_s && j<ns[l-2]; j++)
					WORD_CROSS_DECODE(a[j],next_next_size);
			}	
			break;
		case 1:
			for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
				WORD_CROSS_DECODE(a[i],next_size);
			break;
		default:
			for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
				FlatrbucDecode(a,ns,l-1,i,next_size,next_s,epb,type);
	}
}

int
rbucDecode(unsigned *a, unsigned *ns, 
		    unsigned l, int elem, int size, int s, int epb, int type)
{ 
	int next_size, i;
	int next_s=  type==MS_EXP? s/epb : s;
	if (l>4) {
		WORD_ZERO_CROSS_DECODE(next_size,size);
		for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
			rbucDecode(a,ns,l-1,i,next_size,next_s,epb,type);
	}
  else if (l==4) {
		WORD_ZERO_CROSS_DECODE(next_size,size);
		for (i=elem*s; i<(elem+1)*s && i<ns[l-1]; i++)
    	FlatrbucDecode(a,ns,l-1,i,next_size,next_s,epb,type);
	}
  else
		FlatrbucDecode(a,ns,l,elem,size,s,epb,type);
}


/* elp: elems per blocks at the leaf level
   type: see rbuc_coder.h
*/

int
rbucEncodeFile(unsigned *a, char *ifile, char *ofile,
    int text_file, int sequence_type, unsigned N, unsigned p,
    unsigned *global_max, unsigned *global_sum, unsigned *global_n,
		int epb, int type, int verbose)
{
  FILE *f=NULL,*inf=NULL;      /* output, input file */
	unsigned levels, ns[MAX_LEVELS];
	
	unsigned char *bits[MAX_LEVELS];
	int curr_epb;
	int notOk= 0;
	int org_epb= epb;
	
  int avail, elems;
  unsigned size, max_bits;
  int i,j;
  unsigned char *table, *base;
  unsigned len= 0;   /* total codelength in machine words */
  double Pr=0;
  unsigned curr=0;
  unsigned n;
	unsigned totaln=0;
  
  
  /* alloc mem for handling _bits_ tree */ 
	bits[0]=NULL;                      
	if (org_epb)
	   levels= rbucLevels(ELEMS_PER_BLOCK,epb,type,ns,&curr_epb);
	else	           /* fake for mem all */
	   levels= rbucLevels(ELEMS_PER_BLOCK,2,type,ns,&curr_epb);
  for (i=0; i<levels; i++) {
		if ( !(bits[i]= (unsigned char*) malloc(sizeof(unsigned char)*ns[i]))) {
			fprintf(stderr, "Out of memory\n");
			exit(1);
		}
	}
	
  /* opening input file if needed */
  if (!N)
  {  
    if (!(inf = OpenFile(ifile,"r"))) exit(1);
  }
  else  
    Pr= N/((double)p);

  /* open output file */
  f = OpenFile(ofile,"w") ;
  len= ftell(f); 
  
  
  MS_ENCODE_START(f);
  *global_max= *global_sum= *global_n= 0;
  i=0;
  while (1)
  {
	  i++;	
    if (Pr)
      n= CreateDocGaps(a,&p,Pr);
    else  
      ReadDocGaps(a,&n,inf,text_file,sequence_type,&curr);
    MS_BLOCK_ENCODE_START(n);
		
		if (verbose)
      max_bits= CalcStats(a,n,global_max, global_sum,global_n);
    
		/* find the bit size of each elems */
	  CaclBitSize(a,bits[0],n);
		
		/* find the optimal s */
		if (!org_epb)
			epb= rbucOptimalEpb(bits,n,epb,type);
		
		/* recalculting Levels if needed */
		if (org_epb==0 || n<ELEMS_PER_BLOCK)
			levels= rbucLevels(n,epb,type,ns,&curr_epb);

		/* building the bits tree */
		CaclrbucBits(a,bits,ns,levels, epb, type);
		
		/* Encoding all levels */
		if (!org_epb) {  /* encoding the epb value */
			WORD_CROSS_ENCODE(epb, BITS_FOR_ELEMS_PER_BLOCK);
		}
		rbucEncode(a,bits,ns,levels-1,0,6,curr_epb,epb,type);
		
		totaln += n;
    if (n<ELEMS_PER_BLOCK)
      break;
  }

  
  MS_ENCODE_END;
  
  len = (ftell(f)-len)>>2;
  if (*ofile) fclose(f);
  if (*ifile) fclose(inf);
  for (i=1; i<levels; i++) {
		free(bits[i]);
	}
  return len;
}


int
rbucDecodeFile(unsigned *a,  char *ifile,
    char *ofile, int text_file, int sequence_type,
		int epb, int type)
{
  FILE *f;
  FILE *outf=NULL;
  register unsigned i;
  unsigned n;
  unsigned curr= 0;
	int max_bits;
	unsigned levels, ns[MAX_LEVELS];
	int curr_epb;
	int org_epb= epb;
  
  /* open input file */
  f = OpenFile(ifile,"r") ;
  if (!(outf = OpenFile(ofile, "w"))) return 0;
  
  
  MS_DECODE_START(f);

	if (org_epb)
    levels= rbucLevels(ELEMS_PER_BLOCK,epb,type,ns,&curr_epb);
  while(1)
  {
    MS_BLOCK_DECODE_START(n);
		if (!org_epb) {  /* encoding the epb value */
			WORD_CROSS_DECODE(epb, BITS_FOR_ELEMS_PER_BLOCK);
		}
		if (!org_epb || n<ELEMS_PER_BLOCK)
	    levels= rbucLevels(n,epb,type,ns,&curr_epb);

		rbucDecode(a,ns,levels-1,0,6,curr_epb,epb,type);
		
    if (!WriteDocGaps(outf, a, n, ofile, text_file, sequence_type,&curr)) return 0;
    if (n<ELEMS_PER_BLOCK) break;
  }
  MS_DECODE_END;
  if (*ifile) fclose(f);
  if (*ofile) fclose(outf);
  return 1;
}

