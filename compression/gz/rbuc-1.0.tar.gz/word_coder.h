/**************************************************************************
 *
 * word_coder.h -- tools for coding at word levels
 *                 part of "rbuc"
 * 
 *
 * "rbuc" is the demonstration of the coding scheme "RBUC-B",
 * described in the paper "Binary Codes for Non-Uniform Sources"
 * by Moffat and Anh, to appear in the Proceedings of 
 * 2005 Data Compression Conference.
 *   
 * Copyright (C) 2005  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 
 * We ask that, if you use this software to derive experimental results
 * that are reported in any way, you cite the original work in which the
 * underlying processes are described (by referencing the listed paper);
 * and also acknowledge our authorship of the implementation you have
 * used.

 * BUGS
 * rbuc has not been extensively tested, and should be used for research
 * purposes only.
 * Portability is not guaranteed.
 * There is no warranty, either express or implied, that it is fit for
 * any purpose whatsoever, and neither the authors nor The University of
 * Melbourne accept any responsibility for any consequences that may
 * arise from your use of this software.

 * LICENSE
 * Use and modify for your personal use, but do not distribute in any
 * way shape or form (for commercial or noncommercial purposes, modified
 * or unmodified, including by passively making it available on any
 * internet site) without prior consent of the authors.

 * AUTHORS
 * Vo Ngoc Anh and Alistair Moffat,
 * Department of Computer Science and Software Engineering,
 * The University of Melbourne,
 * Victoria 3010, Australia.
 * Email: vo@cs.mu.oz.au, alistair@cs.mu.oz.au.
 *
 *
 **************************************************************************/

#ifndef _WORD_CODERH
#define _WORD_CODERH

#define WORD_BUFFER_SIZE 2048

static unsigned __mask[33]= {						
  0x00U, 0x01U, 0x03U, 0x07U, 0x0FU,					
  0x1FU, 0x3FU, 0x7FU, 0xFFU,						
  0x01FFU, 0x03FFU, 0x07FFU, 0x0FFFU,					
  0x1FFFU, 0x3FFFU, 0x7FFFU, 0xFFFFU,					
  0x01FFFFU, 0x03FFFFU, 0x07FFFFU, 0x0FFFFFU,				
  0x1FFFFFU, 0x3FFFFFU, 0x7FFFFFU, 0xFFFFFFU,				
  0x01FFFFFFU, 0x03FFFFFFU, 0x07FFFFFFU, 0x0FFFFFFFU,			
  0x1FFFFFFFU, 0x3FFFFFFFU, 0x7FFFFFFFU, 0xFFFFFFFFU }; 

#define GET_AVAILABLE_BITS __wremaining

static int __wremaining;
static unsigned __value[32], __bits[32];
static int __pvalue;
static FILE *__wfile;

/* specific for decoding */
static unsigned __wval;					
static unsigned __buffer[WORD_BUFFER_SIZE];
static unsigned *__buffend;
static unsigned *__wpos;

#define WORD_ENCODE_START(f)						\
  __wremaining = 32;						\
  __pvalue = 0;									\
  __wfile= (f)
  
/* Write one coded word */  
#define WORD_ENCODE_WRITE												\
do {																						\
    register unsigned word; unsigned w;					\
    word= __value[--__pvalue];									\
    for (--__pvalue; __pvalue >=0; __pvalue--)	\
    {																						\
      word <<= __bits[__pvalue];								\
      word |= __value[__pvalue];								\
    }																						\
    w= word;																		\
    fwrite((char*)&w,sizeof(w),1,__wfile);			\
    __wremaining = 32;													\
    __pvalue = 0;																\
} while(0)	
  
/* Encode int x>0 in b bits */
#define WORD_ENCODE(x,b)						\
do {									\
  if (__wremaining<b) WORD_ENCODE_WRITE;				\
  __value[__pvalue]= (x)-1;						\
  __bits[__pvalue++]= (b);						\
  __wremaining -= (b);							\
} while (0)

#define WORD_ZERO_ENCODE(x,b)						\
do {									\
  if (__wremaining<b) WORD_ENCODE_WRITE;				\
  __value[__pvalue]= (x);						\
  __bits[__pvalue++]= (b);						\
  __wremaining -= (b);							\
} while (0)


#define WORD_CROSS_ENCODE(x,b)						\
do {																			\
  register unsigned __x= (x)-1;						\
  register unsigned __b= (b);							\
  if (__wremaining<__b)										\
  {																				\
    if (__wremaining>0)										\
    {																			\
      __value[__pvalue]= __x >> (__b-__wremaining);			\
      __bits[__pvalue++]= __wremaining;		\
      __x <<= (32-((__b-__wremaining)));	\
      __x >>= (32-((__b-__wremaining)));	\
      __b -=  __wremaining;								\
    }																			\
    WORD_ENCODE_WRITE;										\
  }																				\
	if (__b) {															\
  __value[__pvalue]= __x;									\
  __bits[__pvalue++]= __b;								\
  __wremaining -= __b;										\
	}																				\
} while (0)

#define WORD_ZERO_CROSS_ENCODE(x,b)				\
do {																			\
  register unsigned __x= (x);							\
  register unsigned __b= (b);							\
	int tmp= __wremaining;									\
  if (__wremaining<__b)										\
  {																				\
    if (__wremaining>0)										\
    {																			\
      __value[__pvalue]= __x >> (__b-__wremaining);			\
      __bits[__pvalue++]= __wremaining;		\
      __x <<= (32-((__b-__wremaining)));	\
      __x >>= (32-((__b-__wremaining)));	\
      __b -=  __wremaining;								\
    }																			\
    WORD_ENCODE_WRITE;										\
  }																				\
	if (__b) {															\
  __value[__pvalue]= __x;									\
  __bits[__pvalue++]= __b;								\
  __wremaining -= __b;										\
	}																				\
} while (0)


#define WORD_CROSS_DECODE(x,b)							\
  if (__wremaining<b)												\
  {																					\
    __wremaining= (b) - __wremaining;				\
    x= __wval << __wremaining;							\
		GET_NEW_WORD;														\
    x |= (__wval & __mask[__wremaining]); 	\
    x++;																		\
    __wval >>= __wremaining;								\
    __wremaining= 32 - __wremaining;				\
  }																					\
  else 																			\
  {																					\
    x= (__wval & __mask[b]) + 1;						\
    __wval >>= b;														\
    __wremaining -= b;											\
  }



#define WORD_ZERO_CROSS_DECODE(x,b)					\
  if (__wremaining<b)												\
  {																					\
    __wremaining= (b) - __wremaining;				\
    x= __wval << __wremaining;							\
		GET_NEW_WORD;														\
    x |= (__wval & __mask[__wremaining]); 	\
    __wval >>= __wremaining;								\
    __wremaining= 32 - __wremaining;				\
  }																					\
  else 																			\
  {																					\
    x= __wval & __mask[b];									\
    __wval >>= b;														\
    __wremaining -= b;											\
  }																					

#define WORD_ENCODE_END							\
  if (__pvalue) WORD_ENCODE_WRITE;	


/* ======================= MACROS FOR WORD DECODING ============ */

#define WORD_DECODE_START(f)						\
	__wfile= (f);								\
  __buffend= __buffer;				\
  __wpos=__buffer+1;					\
  GET_NEW_WORD;								\
  __wremaining = 32
  
#define GET_NEW_WORD															\
  if (__wpos<__buffend) __wval= *__wpos++;				\
  else																						\
  {																								\
    int tmp;																			\
    if ( (tmp=fread((char*)&__buffer,sizeof(unsigned),WORD_BUFFER_SIZE,__wfile))<1)																								\
    {																							\
      fprintf (stderr, "Error when reading input file\n");		\
      exit(1);																		\
    }																							\
    __wpos= __buffer;															\
    __buffend= __buffer+tmp;											\
    __wval= *__wpos++;														\
  }
    
  
#define WORD_DECODE(x,b)						\
do {									\
  if (__wremaining < (b))						\
  {  									\
    GET_NEW_WORD							\
    __wremaining = 32;							\
  }									\
  (x) = (__wval & __mask[b]) + 1;					\
  __wval >>= (b);							\
  __wremaining -= (b);							\
} while (0)

#define WORD_ZERO_DECODE(x,b)						\
do {									\
  if (__wremaining < (b))						\
  {  									\
    GET_NEW_WORD							\
    __wremaining = 32;							\
  }									\
  (x) = __wval & __mask[b];						\
  __wval >>= (b);							\
  __wremaining -= (b);							\
} while (0)

#define WORD_DECODE_END						



#endif
