/**************************************************************************
 *
 * uncompress_io.h -- io uncompressed files
 * 
 *
 * "rbuc" is the demonstration of the coding scheme "RBUC-B",
 * described in the paper "Binary Codes for Non-Uniform Sources"
 * by Moffat and Anh, to appear in the Proceedings of 
 * 2005 Data Compression Conference.
 *   
 * Copyright (C) 2005  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 
 * We ask that, if you use this software to derive experimental results
 * that are reported in any way, you cite the original work in which the
 * underlying processes are described (by referencing the listed paper);
 * and also acknowledge our authorship of the implementation you have
 * used.

 * BUGS
 * rbuc has not been extensively tested, and should be used for research
 * purposes only.
 * Portability is not guaranteed.
 * There is no warranty, either express or implied, that it is fit for
 * any purpose whatsoever, and neither the authors nor The University of
 * Melbourne accept any responsibility for any consequences that may
 * arise from your use of this software.

 * LICENSE
 * Use and modify for your personal use, but do not distribute in any
 * way shape or form (for commercial or noncommercial purposes, modified
 * or unmodified, including by passively making it available on any
 * internet site) without prior consent of the authors.

 * AUTHORS
 * Vo Ngoc Anh and Alistair Moffat,
 * Department of Computer Science and Software Engineering,
 * The University of Melbourne,
 * Victoria 3010, Australia.
 * Email: vo@cs.mu.oz.au, alistair@cs.mu.oz.au.
 *
 **************************************************************************/

#ifndef _RBUC_INTERFACE
#define _RBUC_INTERFACE

#define LIMIT 10000000
#define MAXN 1000000
#define DOCGAP 0
#define DOCNUM 1
#define ENCODING 0
#define DECODING 1
#define MAXFILENAME 255
#define MAXVALUE 0x10000000U

FILE *
OpenFile(char *filename, char *mode);

int
ReadDocGaps(unsigned int *a, unsigned int *n, FILE *f,
  int text_file, int flag, unsigned *global_curr);

int
WriteDocGaps(FILE *f, unsigned int *a, unsigned int n, char *filename,
  int text_file, int flag, unsigned *global_curr);

int
CreateDocGaps(unsigned *a, unsigned *nn, double Pr);
  
  

#endif  
