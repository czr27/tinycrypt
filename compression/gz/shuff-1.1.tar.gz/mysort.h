#ifndef _MYTYPES_H
    #include "mytypes.h"
#endif

void indirect_sort(uint *, uint *, uint *, uint n);
