void calculate_minimum_redundancy(uint freq[], uint syms[], int n);
