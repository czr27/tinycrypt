void nqsort(char *a, unsigned int n, int es, int (*cmp)(char *, char *));

