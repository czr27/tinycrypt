#ifndef _MYTYPES_H

    #define _MYTYPES_H

    typedef unsigned int  uint;
    typedef unsigned long ulong;

#endif

