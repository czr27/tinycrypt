/**************************************************************************
 *
 * uncompress_io.c -- function for io uncompressed files
 *                    part of "carry"
 * 
 * "carry" is the demonstration of inverted list coding scheme
 *   "carryover12", described in the paper "Inverted Index Compression
 *   using Word-aligned Binary Codes" by Anh and Moffat, which has been
 *   submitted for publication to the "Information Retrieval" journal
 *   
 * Copyright (C) 2003  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 **************************************************************************/

#ifdef RCSID
static char *RCSID = "$Id: uncompress_io.c, v 1.0 2003/10/10$";
#endif


#include <stdio.h>
#include <stdlib.h>
#include "uncompress_io.h"
#include "carry_coder.h"

FILE *
OpenFile(char *filename, char *mode)
{
  FILE *f= NULL;
  if (*filename)
    {
    if (!(f = fopen(filename, mode)))
      fprintf(stderr, "Cannot open file %s\n", filename);
    }
  else 
    f= *mode=='r'? stdin : stdout ;

  return f;
}  
    



/*-------------------------
   Read at most "*n" intergers from "filename" to "a"
   flag = 0 : input numbers intepreted as document gaps
   flag = 1 : input numbers intepreted as document number
   text_file = 1 if reading from a text file
   return 1 if Ok, 0 otherwise; 
          *n = number of items read;
-------------------------*/
   
int
ReadDocGaps(unsigned int *a, unsigned int *n, FILE *f, 
    int text_file, int flag, unsigned *global_curr)
{
  int i;
  unsigned curr=*global_curr;
  int tmp;

  for (i=0; !feof(f) && i<ELEMS_PER_BLOCK; i++)
  {
    if (text_file)
      if ( fscanf(f, " %d ", &tmp) != 1)
      {
         fprintf(stderr, "Errors when reading file\n");
         exit(1);
      }
    if (!text_file)
      if ( fread( (char*) &tmp, sizeof(int), 1, f) != 1)
      {
	 if (feof(f)) { break;};
         fprintf(stderr, "Errors when reading file \n");
         exit(1);
      }
    
    if (flag==DOCNUM)
    {
      if (tmp <= curr)
      {
	fprintf(stderr, "Error: sequence not in increasing order"
	                " at item number %d\n",i+1);
	fprintf(stderr, "Suggestion: when using -d option for compression "
	    "be sure that the input file is a sequence of positive"
	    " numbers in strictly increasing order\n");
	    
	exit(1);
      }
      a[i] = tmp - curr;
      curr = tmp;
    }
    else
    {
      if (tmp <= 0)
      {
	fprintf(stderr, "Error: invalid d-gap"
	                " at item number %d\n",i+1);
	exit(1);
      }
      a[i]= tmp;
    }
  }
  *n = i;
  *global_curr= curr;
  return i;
}


/*-------------------------
 Write "n" item from "a" to file "filename"
-------------------------*/   

int
WriteDocGaps(FILE *f, unsigned int *a, unsigned int n, char *filename, int text_file, int flag, unsigned *global_curr)
{
  unsigned i;
 
  if (flag==DOCNUM)
  { 
    a[0] = *global_curr + a[0];
    for (i=1; i<n; i++) a[i] += a[i-1];
    *global_curr= a[n-1];
  }
      
  if (text_file)
    for (i=0; i<n; i++)
    {
      if ( fprintf(f,"%u\n", a[i]) <1 )
      {
        fprintf(stderr, "Errors when writing file %s\n", filename);
        return 0;
      }
    }
  else
    if ( fwrite( (char*) a, sizeof(unsigned int), n, f) != n)
    {
      fprintf(stderr, "Errors when writing file %s\n", filename);
      return 0;
    }
  
  return 1;
}
  


/*-------------------------
-------------------------*/   
int 
CreateDocGaps(unsigned *a, unsigned *nn, double Pr)
{
  double pr;
  char *A;
  int x,i,j;
  unsigned N, n= *nn;
  unsigned newn;
  
  if (n<1) return 0;
  
  if (n>ELEMS_PER_BLOCK)
  {
    n= ELEMS_PER_BLOCK;
  }
  N= n*Pr + 0.5;
  if (N<n) N=n;
  *nn= *nn - n;
  newn= n;
    
  if (N>LIMIT)
  {
    fprintf (stderr, "Value -N and/or -p not appropriate\n");
    exit(1);
  }
  
  if (!(A = malloc(N)))
  {
    fprintf(stderr, "No memory\n");
    exit(1);
  }
  for (i=0; i<N; i++) A[i] = 0;
 
  while (n)
  {
    x = random()%N;
    if (!A[x]) { A[x] = 1; n--; }
  }  
  for (x=0,i=0,j=0; i<N; i++) 
    if (A[i]) {a[j++]= i+1-x; x=i+1;}
  
  free(A);
  return newn;
}

  
  
      
  
  
