/**************************************************************************
 *
 * carry_coder.c -- functions for carryover12 encoding/decoding
 *                  part of "carry"
 * 
 * carry is the demonstration of inverted list coding scheme
 *   "carryover12", described in the paper "Inverted Index Compression
 *   using Word-aligned Binary Codes" by Anh and Moffat, which has been
 *   submitted for publication to the "Information Retrieval" journal
 *   
 * Copyright (C) 2003  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 **************************************************************************/

#ifdef RCSID
static char *RCSID = "$Id: carry_coder.c,v 1.0 2003/10/10$";
#endif

#include <stdio.h>
#include "uncompress_io.h"
#include "carry_coder.h"

/* bits[i]= bits needed to code gaps[i]
   return max(bits[i])
*/
int
CalcMinBits(int *gaps, unsigned char *bits, int n, unsigned *global_max, unsigned *global_sum, unsigned *global_n)
{
  register int i;
  register int max=0;
  register unsigned gmax= *global_max;
  register unsigned gsum= *global_sum;
  CLOG2TAB_VAR;
  
  for (i=0; i<n; i++)
  { 
    
    QCEILLOG_2(gaps[i], bits[i]);
    if (max<bits[i]) max= bits[i];
    if (gmax<gaps[i]) gmax= gaps[i];
    gsum += gaps[i];
  }
  if (max>28)
  {
    fprintf(stderr, "Error: At least one gap exceeds 2^28. It cannot be coded by this method. Terminated.\n");
    exit(1);
  }
  *global_max= gmax;
  *global_sum= gsum;
  *global_n += n;
  return max;
}

/* given codeleng of "len" bits, and "avail" bits available for coding,
 * bits[] - sequence of sizes   
 * Return number_of_elems_coded (possible) if "avail" bits can be used to
 * code the number of elems  with the remaining < "len"
 * Returns 0 (impossible) otherwise
 */
int
elems_coded(int avail, int len, unsigned char *bits,
                int start, int end)
{
  register int i, real_end, max;
  if (len)
  {
    max= avail/len;
    real_end= start + max - 1 <= end ? start + max: end+1; 
    for (i=start; i<real_end && bits[i]<=len; i++);
    if (i<real_end) return 0;
    return real_end-start;
  }
  else
  {
    for (i=start; i<start+MAX_ELEM_PER_WORD && i<=end && bits[i]<=len; i++);
    if (i-start<2) return 0;
    return i-start;
  }  
}
  



int
CarryEncodeFile(unsigned *a, char *ifile, char *ofile,
    int text_file, int sequence_type, unsigned N, unsigned p,
    unsigned *global_max, unsigned *global_sum, unsigned *global_n)
{
  FILE *f=NULL,*inf=NULL;      /* output, input file */
  unsigned char *bits;
  int avail, elems;
  unsigned size, max_bits;
  int i,j;
  unsigned char *table, *base;
  unsigned len= 0;   /* total codelength in machine words */
  double Pr=0;
  unsigned curr=0;
  unsigned n;
  
  
  /* allocating mem for bits[i] - minimal bits needed to code a[i] */
  
  if (! (bits=(unsigned char*)malloc(ELEMS_PER_BLOCK*sizeof(unsigned char))))
  {
    fprintf (stderr, "Out of memory\n");
    exit(1);
  }

  
  /* opening input file if needed */
  if (!N)
  {  
    if (!(inf = OpenFile(ifile,"r"))) exit(1);
  }
  else  
    Pr= N/((double)p);

  /* open output file */
  f = OpenFile(ofile,"w") ;
  len= ftell(f); 
  
  
  CARRY_ENCODE_START(f);
  size = TRANS_TABLE_STARTER;
  *global_max= *global_sum= *global_n= 0;

  while (1)
  {
    if (Pr)
      n= CreateDocGaps(a,&p,Pr);
    else  
      ReadDocGaps(a,&n,inf,text_file,sequence_type,&curr);
    max_bits= CalcMinBits(a,bits,n,global_max, global_sum,global_n);
    CARRY_BLOCK_ENCODE_START(n,max_bits);
  
    for (i=0; i<n; )
    {
      avail = GET_AVAILABLE_BITS;
      table = GET_TRANS_TABLE(avail);
      base= table+(size<<2);       /* row in trans table */
    
      /* 1. Modeling: Find j= the first-fit column in base */	
      for (j=0; j<4; j++)
      {
        size = base[j];
        if (size >avail) 		/* must use next word for data  */
        {
	  avail=32;
	  j=-1;
	  continue;
        }
        if ( elems=elems_coded(avail,size,bits,i,n-1) )
          break;
      }
 
      /* 2. Coding: Code elements using row "base" & column "j" */
      WORD_ENCODE(j+1,2);             /* encoding column */
      for ( ; elems ; elems--, i++)   /* encoding d-gaps */
        WORD_ENCODE(a[i],size);
    }
    if (n<ELEMS_PER_BLOCK)
      break;
  }
  
  
  
  CARRY_ENCODE_END;
  
  len = (ftell(f)-len)>>2;
  if (*ofile) fclose(f);
  if (*ifile) fclose(inf);
  free(bits);
  return len;
}


int
CarryDecodeFile(unsigned *a,  char *ifile,
    char *ofile, int text_file, int sequence_type)
{
  FILE *f;
  FILE *outf=NULL;
  register unsigned i;
  unsigned n;
  unsigned curr= 0;
  
  /* open input file */
  f = OpenFile(ifile,"r") ;
  if (!(outf = OpenFile(ofile, "w"))) return 0;
  
  
  CARRY_DECODE_START(f);

  while(1)
  {
    CARRY_BLOCK_DECODE_START(n);
    for (i=0; i<n; i++)
    {
      CARRY_DECODE(a[i]);
    }
  
    if (!WriteDocGaps(outf, a, n, ofile, text_file, sequence_type,&curr)) return 0;
    if (n<ELEMS_PER_BLOCK) break;
  }
  CARRY_DECODE_END;
  if (*ifile) fclose(f);
  if (*ofile) fclose(outf);
  return 1;
}

