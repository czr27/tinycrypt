/**************************************************************************
 *
 * uncompress_io.h -- io uncompressed files
 * 
 * CarryOver is the demonstration of inverted list coding scheme
 *   "carryover12", described in the paper "Inverted Index Compression
 *   using Word-aligned Binary Codes" by Anh and Moffat, which has been
 *   submitted for publication to the "Information Retrieval" journal
 *   
 * Copyright (C) 2003  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 **************************************************************************/

#ifdef RCSID
static char *RCSID = "$Id: uncompress_io.h, v 1.0 2003/10/10$";
#endif


#ifndef _CARRY_INTERFACE
#define _CARRY_INTERFACE

#define LIMIT 10000000
#define MAXN 1000000
#define DOCGAP 0
#define DOCNUM 1
#define ENCODING 0
#define DECODING 1
#define MAXFILENAME 255
#define MAXVALUE 0x10000000U

FILE *
OpenFile(char *filename, char *mode);

int
ReadDocGaps(unsigned int *a, unsigned int *n, FILE *f,
  int text_file, int flag, unsigned *global_curr);

int
WriteDocGaps(FILE *f, unsigned int *a, unsigned int n, char *filename,
  int text_file, int flag, unsigned *global_curr);

int
CreateDocGaps(unsigned *a, unsigned *nn, double Pr);
  
  

#endif  
