/**************************************************************************
 *
 * word_coder.h -- tools for coding at word levels
 *                 part of "carry"
 * 
 * "carry" is the demonstration of inverted list coding scheme
 *   "carryover12", described in the paper "Inverted Index Compression
 *   using Word-aligned Binary Codes" by Anh and Moffat, which has been
 *   submitted for publication to the "Information Retrieval" journal
 *   
 * Copyright (C) 2003  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 **************************************************************************/

#ifdef RCSID
static char *RCSID = "$Id: word_coder.h, v 1.0 2003/10/10$";
#endif



#ifndef _WORD_CODERH
#define _WORD_CODERH

#define WORD_BUFFER_SIZE 1024

#define UNSIGNED_MASKS							\
/* __mask[i] is 2^i-1 */						\
static unsigned __mask[33]= {						\
  0x00U, 0x01U, 0x03U, 0x07U, 0x0FU,					\
  0x1FU, 0x3FU, 0x7FU, 0xFFU,						\
  0x01FFU, 0x03FFU, 0x07FFU, 0x0FFFU,					\
  0x1FFFU, 0x3FFFU, 0x7FFFU, 0xFFFFU,					\
  0x01FFFFU, 0x03FFFFU, 0x07FFFFU, 0x0FFFFFU,				\
  0x1FFFFFU, 0x3FFFFFU, 0x7FFFFFU, 0xFFFFFFU,				\
  0x01FFFFFFU, 0x03FFFFFFU, 0x07FFFFFFU, 0x0FFFFFFFU,			\
  0x1FFFFFFFU, 0x3FFFFFFFU, 0x7FFFFFFFU, 0xFFFFFFFFU } 

#define GET_AVAILABLE_BITS __wremaining

#define WORD_ENCODE_START(f)						\
{									\
  int __wremaining = 32;						\
  unsigned __value[32];							\
  unsigned __bits[32];							\
  int __pvalue = 0;							\
  FILE *__wfile= (f)
  
/* Write one coded word */  
#define WORD_ENCODE_WRITE						\
do {									\
    register unsigned word; unsigned w;					\
    word= __value[--__pvalue];						\
    for (--__pvalue; __pvalue >=0; __pvalue--)				\
    {									\
      word <<= __bits[__pvalue];					\
      word |= __value[__pvalue];					\
    }									\
    w= word;								\
    fwrite((char*)&w,sizeof(w),1,__wfile);				\
    __wremaining = 32;							\
    __pvalue = 0;							\
} while(0)	
  
/* Encode int x>0 in b bits */
#define WORD_ENCODE(x,b)						\
do {									\
  if (__wremaining<b) WORD_ENCODE_WRITE;				\
  __value[__pvalue]= (x)-1;						\
  __bits[__pvalue++]= (b);						\
  __wremaining -= (b);							\
} while (0)

#define WORD_ZERO_ENCODE(x,b)						\
do {									\
  if (__wremaining<b) WORD_ENCODE_WRITE;				\
  __value[__pvalue]= (x);						\
  __bits[__pvalue++]= (b);						\
  __wremaining -= (b);							\
} while (0)

#define WORD_ENCODE_END							\
  if (__pvalue) WORD_ENCODE_WRITE;					\
}


/* ======================= MACROS FOR WORD DECODING ============ */

#define WORD_DECODE_START(f)						\
{  									\
  UNSIGNED_MASKS;							\
  register int __wremaining = -1; 					\
  register unsigned __wval = 0;						\
  unsigned __buffer[WORD_BUFFER_SIZE];					\
  register unsigned *__buffend= NULL;					\
  register unsigned *__wpos=__buffer+1;					\
  FILE *__wfile= (f)
  
#define GET_NEW_WORD							\
  if (__wpos<__buffend) __wval= *__wpos++;				\
  else									\
  {									\
    int tmp;								\
    if ( (tmp=fread((char*)&__buffer,sizeof(unsigned),WORD_BUFFER_SIZE,__wfile))<1)					\
    {									\
      fprintf (stderr, "Error when reading input file\n");		\
      exit(1);								\
    }									\
    __wpos= __buffer;							\
    __buffend= __buffer+tmp;						\
    __wval= *__wpos++;							\
  }
    
  
#define WORD_DECODE(x,b)						\
do {									\
  if (__wremaining < (b))						\
  {  									\
    GET_NEW_WORD							\
    __wremaining = 32;							\
  }									\
  (x) = (__wval & __mask[b]) + 1;					\
  __wval >>= (b);							\
  __wremaining -= (b);							\
} while (0)

#define WORD_ZERO_DECODE(x,b)						\
do {									\
  if (__wremaining < (b))						\
  {  									\
    GET_NEW_WORD							\
    __wremaining = 32;							\
  }									\
  (x) = __wval & __mask[b];						\
  __wval >>= (b);							\
  __wremaining -= (b);							\
} while (0)

#define WORD_DECODE_END							\
}



#endif
