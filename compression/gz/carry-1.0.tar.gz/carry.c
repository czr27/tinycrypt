/**************************************************************************
 *
 * carry.c -- driver for the "carry" package
 * 
 * "carry" is the demonstration of inverted list coding scheme
 *   "carryover12", described in the paper "Inverted Index Compression
 *   using Word-aligned Binary Codes" by Anh and Moffat, which has been
 *   submitted for publication to the "Information Retrieval" journal
 *   
 * Copyright (C) 2003  Authors: Vo Ngoc Anh & Alistair Moffat
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 **************************************************************************/

#ifdef RCSID
static char *RCSID = "$Id: icarry.c,v 1.0 2003/10/10$";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "uncompress_io.h"
#include "carry_coder.h"
/* #include "/home/vike/pmt/vo/bin/src/timing/mytiming.h"  */

#define _DEBUG 0
#define yes 1
#define no 0
#define ENCODE 0
#define DECODE 1

void
ProcessArguments(int *coding_type, int *sequence_type, 
    int *text_file, int *s, unsigned *N, unsigned *p,
    char *ifile, char *ofile, int argc, char *argv[]);




int main(int agrc, char *argv[])
{
  int coding_type;
  int sequence_type;
  int text_file;
  int print_stats;
  
  unsigned N;
  unsigned p;

  unsigned len;
  unsigned tmp;
  unsigned *a;
 
  unsigned global_max, global_sum, global_n;

  char ifile[MAXFILENAME+1], ofile[MAXFILENAME+1];

  ProcessArguments(&coding_type, &sequence_type, &text_file, &print_stats,
    &N, &p, ifile, ofile, agrc, argv);
    
  /* TIMING_START; */
  
  if (!(a=(unsigned *) malloc (sizeof(unsigned)*ELEMS_PER_BLOCK)))
  {
    fprintf(stderr,"Cannot allocate memory for the array of docnums\n");
    exit(1);
  }
 
#if _DEBUG > 0  
  fprintf (stderr, "%s elements from %s to %s (uncompressed file is a %s file)\n",
      coding_type==ENCODING? "Encoding":"Decoding",  
      *ifile? ifile : "stdin", *ofile? ofile : "stdout",
      text_file ? "text" : "binary"); 
#endif
  
  if (coding_type==ENCODING)
  {
    if (( len = CarryEncodeFile(a, ifile, ofile,text_file, sequence_type,
            N, p, &global_max, &global_sum, &global_n))< 0)
      return 1;
    if (print_stats)
    {
      int i;
      unsigned max=0;
      float bpd;
      bpd = global_n? (len<<5)/(float)global_n : 0;
      fprintf (stderr, "Number of elements 	= %u\n",global_n);
      fprintf (stderr, "Average d-gap		= %.2f\n",
                global_n? global_sum/(float)global_n : 0);
      fprintf (stderr, "Maximum d-gap 	 	= %u\n",global_max);
      if (bpd>0 && bpd<34)
      {
        fprintf (stderr, "Total output words	= %u\n",len);
        fprintf (stderr, "Mean bits per docnum	= %.2f\n",bpd);
      }
      else
	fprintf (stderr, "Bits per documents not avalable\n"
	                 "To have it, you need to give parameter -o, \n"
			 "  or otherwise redirect output to a file\n");
    }
  }
  else
  {
    if (!CarryDecodeFile(a, ifile, ofile, text_file, sequence_type)) return 1;
  }    
  free(a);
  /* TIMING_END; */
  return 0;
}  


  
/*-------------------------
  Processing arguments to the main()
-------------------------*/

void
ProcessArguments(int *coding_type, int *sequence_type, int *text_file, int *s,
  unsigned *N, unsigned *p, char *ifile, char *ofile,
  int argc, char *argv[])
{
  int error = 0;
  char ch;
  *coding_type = ENCODING;
  *sequence_type = DOCGAP;
  *N= 0;
  *p= 0;
  *s= 0;
  *ifile = '\0';
  *ofile = '\0';
  *text_file = no;
 
  while ((ch = getopt (argc, argv, "vxdhtN:p:i:o:")) != -1)
    switch (ch)
    {
      case 'x':
        *coding_type = DECODING;
        break;
      case 'd':
        *sequence_type = DOCNUM;
        break;
      case 't':
        *text_file = yes;
        break;
      case 'v':
        *s = yes;
        break;
      case 'N':
	*N= atoi(optarg);
	break;
      case 'p':
        *p= atoi(optarg);
        break;
      case 'i':
        strncpy(ifile,optarg,MAXFILENAME);
        break;
      case 'o':
        strncpy(ofile,optarg,MAXFILENAME);
        break;
      case 'h':
      default :
        error = 1;
	break;
    }
  if (optind < argc) error = 1;
  if ( *N && !(*p) || !(*N) && *p
       || *N && *ifile
     )  
    error = 1;
  if (error)
  {
    fprintf(stderr,
	"-------------------------------------------------------------\n"
	"   This program compress/decompress sequence of document\n"
	"numbers/gaps using carryover12 method, described in the\n"
	"paper \"Inverted Index Compression using Word-Aligned \n"
	"Binary Codes\" by Vo Ngoc Anh and Alistair Moffat\n"
	"-------------------------------------------------------------\n");
	
    fprintf( stderr, 
       "Usage:\n%s\t[-x] : extract file instead of compress \n"
       "\t[-d] : uncompressed sequence is of docnums, instead of d-gaps \n"
       "\t[-t] : uncompressed sequence is of text form instead of binary \n"
       "\t[-N N -p p] : generating p docnums valued up to N, OR \n"
       "\t\t[-i input_file_name] : default= stdin \n"
       "\t[-o output_file_name] : default= stdout\n"
       "\t[-v] : (verbose:) print statistics (not working with -x option)\n"
       "\t[-h] : print this message \n", argv [0]);
    fprintf( stderr,
	"-------------------------------------------------------------\n"
        "Examples:	\n"
	"\tcarry -i SMALL -o BIG        : compress file \"SMALL\", write to \"BIG\"\n"
	"\tcarry < SMALL > BIG          : same as above\n"
	"\tcarry -t < SMALL > BIG       : same as above,\n"
	"\t                               but \"SMALL\" is in text format\n"
	"\tcarry -t -d < SMALL > BIG    : same as above,\n"
	"\t                               but \"SMALL\" contains sequence\n"
	"\t                               of document numbers, not gaps\n"
	"\tcarry -x -t < BIG            : Decompress file \"BIG\",\n"
	"\t                               and write text output to stdout\n"
	"\tcarry -N 10000 -p 100 > SMALL: randomly generate 100 document numbers\n"
	"\t                               for a hypothesis collection of 10000\n"
	"\t                               docs, compress them to \"SMALL\"\n");   
    fprintf( stderr,
	"-------------------------------------------------------------\n"
	"   Thank you for using this program.\n"
        "   If you have any comment, please send to vo@cs.mu.oz.au.\n\n");
    exit(1);
  }
  
  if (*N && (*N<*p ||  ( *p<(1<<12) &&  *N> (*p<<25) )) )
  {
    fprintf (stderr, "Value -N and/or -p not appropriate\n");
    exit(1);
  }
  
  return;
}
       
