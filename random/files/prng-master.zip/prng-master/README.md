prng
====

PRNG experiments based on http://burtleburtle.net/bob/rand/smallprng.html
